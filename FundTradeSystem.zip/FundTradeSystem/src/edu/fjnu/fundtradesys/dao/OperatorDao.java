/**
 * 
 */
package edu.fjnu.fundtradesys.dao;

import edu.fjnu.fundtradesys.domain.Operator;

public interface OperatorDao {
	
	Operator getOperatorByNo(Integer opeNo);

}
