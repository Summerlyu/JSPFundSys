package edu.fjnu.fundtradesys.service;

import edu.fjnu.fundtradesys.domain.FundTransInfo;
import edu.fjnu.fundtradesys.utils.Page;

public interface FundTransService {

	/**
	 * 
	* @Title: add
	* @Description: ���ӻ����׼�¼
	* @param @param fundtransinfo   
	* @return void    
	* @throws
	 */
	void add(FundTransInfo fundtransinfo);
	/**
	 * 
	* @Title: loadPagedTradeRecord
	* @Description: ��ҳ��ѯ�����׼�¼
	* @param @param page
	* @param @param fundtransinfo
	* @param @return   
	* @return Page    
	* @throws
	 */
	Page loadPagedTradeRecord(Page page,FundTransInfo fundtransinfo);

}
