package edu.fjnu.fundtradesys.service;

import edu.fjnu.fundtradesys.domain.Operator;

public interface OperatorService {
	/**
	 * 
	* @Title: checkOperator
	* @Description: ����Ա��¼��֤
	* @param @param operCode
	* @param @param operPwd
	* @param @return   
	* @return Operator    
	* @throws
	 */
	Operator checkOperator(Integer operCode,String operPwd);

}
