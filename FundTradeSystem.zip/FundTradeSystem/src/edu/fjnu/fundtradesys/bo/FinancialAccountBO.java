package edu.fjnu.fundtradesys.bo;

import java.sql.Date;

public class FinancialAccountBO {
	
	/**
	 * �˺�
	 */
	private Integer acc_no;
	/**
	 * ����
	 */
	private String pass;
	/**
	 * ���ʽ�
	 */
	private float money;
	/**
	 * ״̬
	 */
	private String status;
	/**
	 * �ͻ�ID
	 */
	private Integer clientno;
	/**
	 * ����֤��
	 */
	private String idcard_no;
	/**
	 * ��������
	 */
	private Date date;
	/**
	 * ����Ա���
	 */
	private String opercode;
	public Integer getAcc_no() {
		return acc_no;
	}
	public void setAcc_no(Integer acc_no) {
		this.acc_no = acc_no;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	public float getMoney() {
		return money;
	}
	public void setMoney(float money) {
		this.money = money;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Integer getClientno() {
		return clientno;
	}
	public void setClientno(Integer clientno) {
		this.clientno = clientno;
	}
	public String getIdcard_no() {
		return idcard_no;
	}
	public void setIdcard_no(String idcard_no) {
		this.idcard_no = idcard_no;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public String getOpercode() {
		return opercode;
	}
	public void setOpercode(String opercode) {
		this.opercode = opercode;
	}

}
