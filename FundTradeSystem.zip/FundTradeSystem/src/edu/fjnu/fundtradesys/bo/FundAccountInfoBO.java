package edu.fjnu.fundtradesys.bo;

public class FundAccountInfoBO {

	/**
	 * �˺�
	 */
	private Integer acc_no;
	/**
	 * ����֤��
	 */
	private String idcard_no;
	/**
	 * �ͻ�����
	 */
	private String client_name;
	/**
	 * ��������
	 */
	private String fund_name;
	/**
	 * ����
	 */
	private float amount;

	public Integer getAcc_no() {
		return acc_no;
	}

	public void setAcc_no(Integer acc_no) {
		this.acc_no = acc_no;
	}

	public String getIdcard_no() {
		return idcard_no;
	}

	public void setIdcard_no(String idcard_no) {
		this.idcard_no = idcard_no;
	}

	public String getClient_name() {
		return client_name;
	}

	public void setClient_name(String client_name) {
		this.client_name = client_name;
	}

	public String getFund_name() {
		return fund_name;
	}

	public void setFund_name(String fund_name) {
		this.fund_name = fund_name;
	}

	public float getAmount() {
		return amount;
	}

	public void setAmount(float amount) {
		this.amount = amount;
	}
}
