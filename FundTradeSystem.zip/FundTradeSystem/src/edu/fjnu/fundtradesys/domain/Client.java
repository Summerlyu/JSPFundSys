package edu.fjnu.fundtradesys.domain;

import java.sql.Date;

/**
 * 
 * @ClassName: Client
 * @Description: �� Client���ͻ���Ϣ��
 * @author wuhm �����
 * @date 2013-1-1 ����5:26:55
 * 
 */
public class Client extends ValueObject {
	/**
	 * �ͻ���� ��������
	 */
	private Integer clientNo;
	/**
	 * ����֤��
	 */
	private String idcardNo;
	/**
	 * �ͻ�����
	 */
	private String clientName;
	/**
	 * �Ա�
	 */
	private String clientSex;
	/**
	 * �绰
	 */
	private String clientPhone;
	/**
	 * �����ַ
	 */
	private String clientEmail;
	/**
	 * סַ
	 */
	private String clientAddress;
	/**
	 * ����
	 */
	private String clientHobby;
	/**
	 * ��������
	 */
	private Date createDate;
	/**
	 * ����Ա���
	 */
	private String operCode;

	public Integer getClientNo() {
		return clientNo;
	}

	public void setClientNo(Integer clientNo) {
		this.clientNo = clientNo;
	}

	public String getIdcardNo() {
		return idcardNo;
	}

	public void setIdcardNo(String idcardNo) {
		this.idcardNo = idcardNo;
	}

	public String getClientName() {
		return clientName;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	public String getClientSex() {
		return clientSex;
	}

	public void setClientSex(String clientSex) {
		this.clientSex = clientSex;
	}

	public String getClientPhone() {
		return clientPhone;
	}

	public void setClientPhone(String clientPhone) {
		this.clientPhone = clientPhone;
	}

	public String getClientEmail() {
		return clientEmail;
	}

	public void setClientEmail(String clientEmail) {
		this.clientEmail = clientEmail;
	}

	public String getClientAddress() {
		return clientAddress;
	}

	public void setClientAddress(String clientAddress) {
		this.clientAddress = clientAddress;
	}

	public String getClientHobby() {
		return clientHobby;
	}

	public void setClientHobby(String clientHobby) {
		this.clientHobby = clientHobby;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public String getOperCode() {
		return operCode;
	}

	public void setOperCode(String operCode) {
		this.operCode = operCode;
	}

}
