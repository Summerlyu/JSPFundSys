package edu.fjnu.fundtradesys.domain;
/**
 * 
* @ClassName: Operator
* @Description: �� bank_Operator������Ա��
* @author wuhm �����
* @date 2013-1-1 ����5:24:35
*
 */
public class Operator extends ValueObject {
	/**
	 * ����Ա���
	 */
	private String operCode;
	/**
	 * ����Ա����
	 */
	private String operName;
	/**
	 * ����Ա����
	 */
	private String operPwd;
	/**
	 * ����Ա��ϵ�绰
	 */
	private String operContact;

	public String getOperCode() {
		return operCode;
	}

	public void setOperCode(String operCode) {
		this.operCode = operCode;
	}

	public String getOperName() {
		return operName;
	}

	public void setOperName(String operName) {
		this.operName = operName;
	}

	public String getOperPwd() {
		return operPwd;
	}

	public void setOperPwd(String operPwd) {
		this.operPwd = operPwd;
	}

	public String getOperContact() {
		return operContact;
	}

	public void setOperContact(String operContact) {
		this.operContact = operContact;
	}

}
