package edu.fjnu.fundtradesys.domain;

import java.sql.Date;

/**
 * ��financial_account ���ͻ��ʽ��˻���
 * 
 * @author Administrator
 * 
 */
public class FinancialAccount extends ValueObject {
	/**
	 * �ʽ��˻��˺�
	 */
	private Integer acc_no;
	/**
	 * �ʽ��˻�����
	 */
	private String acc_pwd;
	/**
	 * ��ǰ�����ʽ���
	 */
	private float acc_amount;
	/**
	 * �˻�״̬
	 */
	private String acc_status;
	/**
	 * �ͻ����
	 */
	private Integer client_no;
	/**
	 * ��������
	 */
	private Date create_date;
	/**
	 * ����Ա���
	 */
	private String Oper_code;

	public Integer getAcc_no() {
		return acc_no;
	}

	public void setAcc_no(Integer acc_no) {
		this.acc_no = acc_no;
	}

	public String getAcc_pwd() {
		return acc_pwd;
	}

	public void setAcc_pwd(String acc_pwd) {
		this.acc_pwd = acc_pwd;
	}

	public float getAcc_amount() {
		return acc_amount;
	}

	public void setAcc_amount(float acc_amount) {
		this.acc_amount = acc_amount;
	}

	public String getAcc_status() {
		return acc_status;
	}

	public void setAcc_status(String acc_status) {
		this.acc_status = acc_status;
	}

	public Integer getClient_no() {
		return client_no;
	}

	public void setClient_no(Integer client_no) {
		this.client_no = client_no;
	}

	public Date getCreate_date() {
		return create_date;
	}

	public void setCreate_date(Date create_date) {
		this.create_date = create_date;
	}

	public String getOper_code() {
		return Oper_code;
	}

	public void setOper_code(String oper_code) {
		Oper_code = oper_code;
	}

}
